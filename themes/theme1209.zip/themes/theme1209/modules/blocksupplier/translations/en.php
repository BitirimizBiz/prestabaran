<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksupplier}prestashop>blocksupplier_9ae42413e3cb9596efe3857f75bad3df'] = 'Suppliers block';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_e72b2501ba75e9ab754d3294d43c2590'] = 'Adds a block displaying your product suppliers.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_85ab0c0d250e58397e95c96277a3f8e3'] = 'Invalid number of elements.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_914b0cd4e4aa7cba84a3fd47b880fd2a'] = 'Please activate at least one type of list.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_f38f5974cdc23279ffe6d203641a8bdf'] = 'Settings updated.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_bfdff752293014f11f17122c92909ad5'] = 'Use a plain-text list';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_78b2098aa1d513b5e1852b3140c7ee26'] = 'Display suppliers in a plain-text list.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_2eef734f174a02ae3d7aaafefeeedb42'] = 'Number of elements to display';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_b0fa976774d2acf72f9c62e9ab73de38'] = 'Use a drop-down list';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_e490c3b296d2f54d65d3d20803f71b55'] = 'Display suppliers in a drop-down list.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_1814d65a76028fdfbadab64a5a8076df'] = 'Suppliers';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_49fa2426b7903b3d4c89e2c1874d9346'] = 'More about';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_ecf253735ac0cba84a9d2eeff1f1b87c'] = 'All suppliers';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_496689fbd342f80d30f1f266d060415a'] = 'No supplier';


return $_MODULE;
